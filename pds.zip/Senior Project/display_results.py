from tkinter import *

def displayMsg():                           #.......... if phishing display warning message.

    root_win = Tk()                         #........... root for the window.
    root_win.iconbitmap('warning_b1s_icon.ico')
    root_win.title('PDS')
    content = "Warning Possible Scam"
    msg = Message(root_win, text = content)
    msg.config(bg='red', font=('times', 40, 'bold'), justify = 'center')

    width = 825
    height = 650

    w_get = root_win.winfo_screenwidth()    #............ setting width.
    h_get = root_win.winfo_screenheight()   #............ setting height.

    x = (w_get/2) - (width/2)
    y = (h_get/2) - (height/2)

    msg.pack(fill = BOTH, expand = True)
    root_win.geometry('%dx%d+%d+%d' % (width, height, x, y))    #............... sets the window locc.
    root_win.mainloop()                                         #............... loops so windows stay inmobile.