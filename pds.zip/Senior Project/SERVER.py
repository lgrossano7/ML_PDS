from flask import Flask, jsonify
from flask import request


import urllib.request as ur
#import jsonify
import numpy as np
import json
import csv
import pandas as pd
import urllib
from feature_check import check_features
from set_dataset import loadCsv, createLabel
from classifier import SVM_classifier, Naive_classifier
from display_results import displayMsg




app = Flask(__name__)

@app.route('/', methods=['POST','GET'])
def postJsonHandler():
	url = None
	print("I got it")
	url1 = request.form['url']
	gather = "url_features"
	write = pd.DataFrame(columns=['URL', 'URL Length', 'IP'])
	extracted_url = []
	getinput = []
	labels = []
	
	##################################################################################
	#url = open('verified_online.csv', 'rU')                              #................... opening the CSV file.
	#for line in url:                                                     #................... iterate the Column.
		#url_cell = line.split(",")                                       #................... split lines.
		#extracted_url.append((url_cell[1]))                              #................... append url's.
	##################################################################################
	
	getinput.append(url1)  #................... Insert input here("FLASK")
	
	##################################################################################
	#print("input length = ", getinput.__len__())
	#features = check_features(extracted_url, 8000, 1)                        #....................... create features.
	##################################################################################
	
	getinput_f = check_features(getinput, getinput.__len__(), 0)
	
	##################################################################################
	##################################################################################
	#print("Check dataset Features = ", features[0], features[0].__len__())
	#print("Check input Features = ", getinput_f[0], getinput_f[0].__len__()) #....................... check input feat.
	#labels = createLabel(features, 8000, 9)                                  #...................... creating labels.
	#try:
	#	for i in range(0, 8000):
	#		write = write.append({'URL': features[i][0], 'URL Length': features[i][1], 'IP': features[i][2], 'Subdomains': features[i][3],'Short': #features[i][4],'https': features[i][5], '//': features[i][6],'@': features[i][7],'-': features[i][8]}, ignore_index=True)
	#except Exception as e:
	#	pass

	#url.close()

	#save = gather.replace(' ', '').replace(')','').replace('(','').replace('/','')+('.csv')
	#print("Here's what you saved =", save)
	#write.to_csv(save)                                             #.......... saving features.

	#filename = 'url_features.csv'

	#print("CSV :", filename[1])
	#dataset = loadCsv(filename)
	##################################################################################
	##################################################################################
	print("\n")

	result = SVM_classifier(0, labels,  getinput_f)    
	print(result)
	list = [{"results": result}]
	
	print(list)
	return jsonify(results = list)
	#return json.dumps(list)
	


if __name__ == '__main__':
   app.run(debug = True, host='localhost', port=5000)
