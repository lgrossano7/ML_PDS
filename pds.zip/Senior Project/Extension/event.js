
// ANOTHER WAY OF IMPLEMENTING THE POST
chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
	sendResponse({farewell:"goodbye"});
	if(message.action == "submit"){
		var url = "data:text/html;charset=utf8,";
		var messurl = message.url;
		console.log(messurl);
		
		function append(key, value){
			var input = document.createElement('textarea');
			input.setAttribute('name',key);
			input.textContent = value;
			form.appendChild(input);		
		}
		
		var form = document.createElement('form');
		form.method = 'POST';
		form.id = 'urlForm';
		form.action =  'http://127.0.0.1:5000/';
		form.style.visibility = "visible";
		append('url', message.url);
		url = url + encodeURIComponent(form.outerHTML);
		//console.log(url);
		url = url + encodeURIComponent('<script>document.getElementById("urlForm").submit();</script>');
		console.log(url);
		//form.submit();
		
		chrome.tabs.create({url:url, active: true});
		return true;
	}
	else{
		console.log("outside");
		return true;
	}
});

