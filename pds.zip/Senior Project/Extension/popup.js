// Copyright (c) 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

chrome.tabs.query({'active':true, 'lastFocusedWindow': true}, function(tabs){
	var url = tabs[0].url;
	create(url);
	// chrome.runtime.sendMessage({
			// action: "submit",
			// url: url,
			// }, function(response){console.log(response.farewell)});
});


chrome.tabs.query({'active':true, 'lastFocusedWindow': true}, function(tabs){
	var url = tabs[0].url;
	console.log("url: " + url);

	var data = {
		"url": url,
	}
	}
);


function create(a){
	$('#message').html("Processing...");
	$.ajax({
		url:'http://127.0.0.1:5000',
		data:{
			url:a
		},
		type:"POST",
		dataType:"json",
	}).done(function (data){
		results = data.results[0].results;
		console.log(results)
		$('#message').replaceWith(results);
	});
}