import csv

def loadCsv(filename):                          #.................... loads the contents of the csv file.

    lines = csv.reader(open(filename, 'r'))
    headers = next(lines, None)
    column = {}
    data = []

    for h in headers:
        column[h] = []

    for row in lines:
        data.append([row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9]])

    n = [[int(float(i)) for i in k] for k in data]

    return n

def createLabel(features, dataSize, loc):      #................... creates the labels for the dataset
    target = []                      #.................... empty list.

    for i in range(0, dataSize):
        target.append(features[i][loc])

    return target                    #.................... returns labels.