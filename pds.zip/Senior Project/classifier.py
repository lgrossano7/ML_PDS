import numpy as np
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import BernoulliNB
from sklearn import cluster                     #........ use for k_means
from sklearn import svm
from display_results import displayMsg
import pickle

def Naive_classifier(training_data, labels):    #....................... Naive Bayes.

    clasF = GaussianNB()                         #....................... Set's Guass.

    X,y = training_data, labels                  #....................... Set's Train and labels(answer key).
    clasF.fit(X, y)                             #....................... Training starts.
    GaussianNB(priors=None)

    print("NAIVE BAYES:")
    print("You are predicting this => ", X[1])  #....................... Checking URL sample.
    print("Sample Prediction => ", clasF.predict(X[10]))   #............ Predicting URL sample.
    print("Probability = ", round(clasF.score(X, y), 3)*100,"%")  #....................... Getting probability.
    print("\n")

def Naive_BC_Bernoulli(training_data, labels):

    ber = BernoulliNB()
    x = np.array(training_data)
    y = np.array(labels)
    ber.partial_fit(x, y)

    print("Bernoulli:")
    print("You are predicting => ", x[1])
    print("Sample Prediction => ", ber.predict(x[10]))
    print("Probability = ", round(ber.score(x, y), 3)*100)


def SVM_classifier(training_data, labels, test):    #....................... SVM classifier.

	class_f = svm.SVC(kernel='linear', C=0.1, gamma='auto')

	#X = np.array(training_data)                     #............... Reshaping training data.
	#y = np.array(labels)                            #............... Reshaping labels.
	trial = np.array(test)                          #............... input testing.
	#class_f.fit(X, y)                            

	#with open('saveClassifier.pickle', 'wb') as save:
		#pickle.dump(class_f, save)
	pickle_open = open('saveClassifier.pickle', 'rb')
	class_f = pickle.load(pickle_open)


	print("SVM:")
	#print("Sample x = ", X[1])
	#print("Sample trial = ", trial[0])
	print("Sample Prediction => ", class_f.predict(trial[0]))
	getPrediction = class_f.predict(trial[0])
	#print("Probability = ",  round(class_f.score(X, y), 3)*100,"%")
	print("\n")

	if(getPrediction[0] >= 1):   #................ if phishing then display "warning".
		#displayMsg()
		return "Phishing"
	else:
		return "Safe"


def k_means(train_d, target):

    x_train = np.array(train_d)
    k_m = cluster.KMeans(n_clusters=3)
    k_m.fit(x_train)
    print("K_Means label = ", k_m.labels_[::10])