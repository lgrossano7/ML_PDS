from urllib.parse import urlparse
import time
import certifi
import requests
import httplib2
import ssl

def check_len(url, size):

    if(size == 1):
        print("CHECK URL: ",url)

    result = 0

    if url.__len__() >= 54 and url.__len__() <=75:      #................... if length is greater 54 but less than 75.
        print('suspicious')
        result = 1
    elif url.__len__() > 75:
        print('definately phish')                       #................... if length is greater than 75.
        result = 1
    else:
        print('not phising')                            #................... length is below 54.
        result = 0

    print("URL length = ", url.__len__())               #.................. print length.
    return result                                       #.................. returns result.

def isIP(url):

    is_Ip = 0
    x =[0 for x in range(url.__len__())]    #........ initialize list.
    for i in range(0, url.__len__()):       #........ iterate to convert to str.
        if(url[i] != '.'):                  #................ checks for dot separation.
            x[i] = url[i]

    test = "".join(str(s) for s in x)       #............ convert str.
    if(test.isdigit()):                     #................ checking possible numbers on str.
        is_Ip = 1                           #................ it is an IP.
    else:
        is_Ip = 0                           #................ not an IP.
    return is_Ip                            #................ return result.

def securePath(path_url):                   #................ checks for secure path.
    print("Check ths content: ", path_url)
    https = path_url.count('s')

    if https < 1:
        print("NOT TRUSTABLE")
        return 1
    else:
        print("IT IS GOOD! ")
        return 0

def check_dots(path):                       #................. checks for extra extensions that might cover URL.
    if 'www.' in path:
        newpath = path.replace('www.', '', 1)
        #print(newpath)
        newpath = newpath.rsplit('.',1)[0]
        #print(newpath)

        print('newpath has dots: ', newpath.count('.'))
        dots = newpath.count('.')
        if dots <= 1:
            print('Legit')
            return 0
        elif dots > 1:
            print('Suspicious')
            return 1
        else:
            print('Phishing')
            return 1
    else:
        newpath = path.rsplit('.', 1)[0]
        #print(newpath)

        print('newpath has dots: ', newpath.count('.'))
        dots = newpath.count('.')
        if dots <= 1:
            return 0
        elif dots > 1:
            print('Suspicious')
            print('Legit')
            return 1
        else:
            print('Phishing')
            return 1

def check_shortUrls(path):                      #...................... checks for short URLs.
    short_urls = ['bit.ly', 'bitly']
    if any(word in path for word in short_urls):
        print('Found: ', short_urls)
        return 1
    else:
        print('No bitly')
        return 0

def webExists(url_e):                           #........................ URL has been taken down?(Y/N).
    request = requests.get(url_e)

    if request.status_code == 200:
        print('Web site exists')
        return 0
    else:
        print('Web site does not exist')
        return 1

def check_redirectering(url_r):
    redict = url_r.count('/')

    if redict > 7:
        return 1
    else:
        return 0

def check_specialChar(url, set):                  #............................. checks special char in URL.
    char = 0
    for c in set:
        if c in url:
            print(set, 'found')
            char = 1
            break
        else:
            print(set, 'not Found')
            char = 0
    return char

def checkValidCertificate(url_in):                #................................ SSL certificate checking.
    res = requests.get(url_in, verify = True, cert = certifi.where())
    print(res)

def check_ssl(url):                               #................................ checks web certificate.
    try:
        page = ''
        while page == '':
            try:
                page = requests.get(url, verify=True)
            except:
                print("Connection refused by the server..")
                time.sleep(5)
                print("Was a nice sleep, now let me continue...")
                continue
        print(url + ' has a valid SSL certificate!')
    except requests.exceptions.SSLError:
        print(url + ' has INVALID SSL certificate!')

def getLabel(features, c, r):      #......................
    counting = 0

    for x in range(1, r):
        if features[c][x] == 1:
            counting += 1
            print(x,"= ",features[c][x], " found")
        else:
            print(x, "= ", features[c][x], " not found")
    return counting

def check_features(urls, size, is_input):                #................... features function.

    ranges = 0

    if(is_input == 1):
        ranges = 10
    else:
        ranges = 8

    phish_count= [[0] * ranges for i in range(size)]
    for i in range(0, size):                                    #................... iterate  columns.
        c = 0                                                   #................... reinitialize counter.
        if(is_input == 1):                                      #................... to access url contents.
            col = i+1
            phish_count[i][c] = (urls[col])                     #................... stores url.
            c+= 1
        else:
            col = 0
			
        p = urlparse(urls[col])                                 #................... parses URL and stores it.
        print("Parsed URL contents: ", p)                       #................... check parsed url contents.
        phish_count[i][c] = (check_len(urls[col], size))        #0................... checking URL length.
        c+=1
        phish_count[i][c] = (isIP(p[1]))                        #1................... checks for IP address on domain.
        c+=1
        phish_count[i][c] = (check_dots(p[1]))                  #2................... checks for dots.
        c+=1
        phish_count[i][c] = (check_shortUrls(p[1]))             #3................... checks for short urls.
        c+=1
        phish_count[i][c] = (securePath(p[0]))                  #4................... checks for http"s".
        c+=1
        phish_count[i][c] = (check_redirectering(urls[col]))    #5............... checks redirection.
        c+=1
        phish_count[i][c] = (check_specialChar(urls[col], '@')) #6............ checks @.
        c+=1
        phish_count[i][c] = (check_specialChar(urls[col], '-')) #7............ checks '-'.
        c+=1

        if(is_input == 1):
            phish_count[i][c] = (getLabel(phish_count, i, c))       #8............ making labels.
            print("Total phishing count[", i + 1, "]", phish_count[i][0], " # LABELS = ",
                  phish_count[i][9])  # .................. check phishing count.

        #check_ssl('https://google.com')
        #check_ssl('https://example.com')

    return phish_count                                      #................... save contents.